document.addEventListener('DOMContentLoaded', async () => {
  // Elements
  const notIgPanel = document.getElementById('not-ig-panel');
  const notLoggedPanel = document.getElementById('not-logged-panel');
  const readyPanel = document.getElementById('ready-panel');
  const progressPanel = document.getElementById('progress-panel');
  const resultsPanel = document.getElementById('results-panel');

  const btnGotoIg = document.getElementById('btn-goto-ig');
  const btnRefreshSession = document.getElementById('btn-refresh-session');
  const btnStartScan = document.getElementById('btn-start-scan');
  const btnCancel = document.getElementById('btn-cancel');
  const btnRestart = document.getElementById('btn-restart');
  const btnCopy = document.getElementById('btn-copy');
  const btnExportCsv = document.getElementById('btn-export-csv');
  const btnCloseWindow = document.getElementById('btn-close-window');
  const btnFetchCategories = document.getElementById('btn-fetch-categories');

  const delayRange = document.getElementById('delay-range');
  const delayVal = document.getElementById('delay-val');

  const followingStats = document.getElementById('following-stats');
  const followingBar = document.getElementById('following-bar');
  const followingStatus = document.getElementById('following-status');

  const followersStats = document.getElementById('followers-stats');
  const followersBar = document.getElementById('followers-bar');
  const followersStatus = document.getElementById('followers-status');

  const statFollowing = document.getElementById('stat-following');
  const statMutual = document.getElementById('stat-mutual');
  const unfollowersCount = document.getElementById('unfollowers-count');
  
  const searchBox = document.getElementById('search-box');
  const filterNiche = document.getElementById('filter-niche');
  const sortList = document.getElementById('sort-list');
  const usersListContainer = document.getElementById('users-list-container');

  let currentTab = null;
  let loggedInUserId = null;
  let csrfToken = "";
  let finalUnfollowers = [];

  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  // Close standalone window
  if (btnCloseWindow) {
    btnCloseWindow.addEventListener('click', () => {
      window.close();
    });
  }

  // Update delay text dynamically
  delayRange.addEventListener('input', () => {
    delayVal.textContent = `${parseFloat(delayRange.value).toFixed(1)}s`;
  });

  // Flow State Controller
  const setPanel = (activePanel) => {
    [notIgPanel, notLoggedPanel, readyPanel, progressPanel, resultsPanel].forEach(panel => {
      panel.style.display = panel === activePanel ? 'flex' : 'none';
    });
  };

  // Redirect to IG
  btnGotoIg.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://www.instagram.com/' });
  });

  // Verify Instagram & Cookie Session Status
  const checkStatus = async () => {
    // 1. Try to get active tab in the last focused browser window (the window the user clicked from)
    let tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    let igTab = null;

    if (tabs && tabs.length > 0 && tabs[0].url && tabs[0].url.includes('instagram.com')) {
      igTab = tabs[0];
    } else {
      // 2. Fallback: Search across all open tabs for any active Instagram page
      tabs = await chrome.tabs.query({ url: "*://*.instagram.com/*" });
      if (tabs && tabs.length > 0) {
        igTab = tabs[0];
      }
    }

    if (!igTab) {
      setPanel(notIgPanel);
      return false;
    }

    currentTab = igTab;

    // Read cookies for session identification and CSRF verification
    try {
      const userCookie = await chrome.cookies.get({
        url: 'https://www.instagram.com',
        name: 'ds_user_id'
      });

      const csrfCookie = await chrome.cookies.get({
        url: 'https://www.instagram.com',
        name: 'csrftoken'
      });

      if (!userCookie || !userCookie.value) {
        setPanel(notLoggedPanel);
        return false;
      } else {
        loggedInUserId = userCookie.value;
        csrfToken = csrfCookie ? csrfCookie.value : "";
        setPanel(readyPanel);
        return true;
      }
    } catch (err) {
      console.error("Cookie fetch error:", err);
      setPanel(notLoggedPanel);
      return false;
    }
  };

  btnRefreshSession.addEventListener('click', async () => {
    await checkStatus();
  });

  // Triggering the Scan Process
  btnStartScan.addEventListener('click', () => {
    if (!currentTab || !loggedInUserId) return;
    setPanel(progressPanel);

    // Reset progress UI elements
    followingBar.style.width = '0%';
    followingStats.textContent = '0 fetched';
    followingStatus.textContent = '⏱️ Scraper initiating...';
    followersBar.style.width = '0%';
    followersStats.textContent = '0 fetched';
    followersStatus.textContent = '⏱️ Waiting for step 2...';

    const delayMs = parseFloat(delayRange.value) * 1000;

    // Directing the content script to execute
    chrome.tabs.sendMessage(currentTab.id, {
      action: "START_SCAN",
      userId: loggedInUserId,
      csrfToken: csrfToken,
      delay: delayMs
    }, (response) => {
      if (chrome.runtime.lastError) {
        // Content script might not be injected. Force inject and restart.
        chrome.scripting.executeScript({
          target: { tabId: currentTab.id },
          files: ['content.js']
        }, () => {
          chrome.tabs.sendMessage(currentTab.id, {
            action: "START_SCAN",
            userId: loggedInUserId,
            csrfToken: csrfToken,
            delay: delayMs
          });
        });
      }
    });
  });

  // Handle updates coming back from content script
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'PROGRESS_UPDATE') {
      const { phase, count, total, currentBatch, state } = message.payload;
      
      if (phase === 'following') {
        const percent = total ? Math.min((count / total) * 100, 100) : 50;
        followingBar.style.width = `${percent}%`;
        followingStats.textContent = `${count}${total ? ' / ' + total : ''}`;
        followingStatus.textContent = state === 'running' 
          ? `🔄 Fetching page (batch size: ${currentBatch})...` 
          : `✅ Done! Loaded ${count} profiles.`;
      } else if (phase === 'followers') {
        const percent = total ? Math.min((count / total) * 100, 100) : 50;
        followersBar.style.width = `${percent}%`;
        followersStats.textContent = `${count}${total ? ' / ' + total : ''}`;
        followersStatus.textContent = state === 'running' 
          ? `🔄 Fetching page (batch size: ${currentBatch})...` 
          : `✅ Done! Loaded ${count} profiles.`;
      }
    }

    if (message.type === 'SCAN_COMPLETE') {
      finalUnfollowers = message.payload.unfollowers;
      const followingCount = message.payload.followingCount || 0;
      const followersCount = message.payload.followersCount || 0;

      unfollowersCount.textContent = finalUnfollowers.length;
      statFollowing.textContent = followingCount;
      statMutual.textContent = Math.max(followingCount - finalUnfollowers.length, 0);

      updateNicheDropdown();
      renderUsers(finalUnfollowers);
      setPanel(resultsPanel);
    }

    if (message.type === 'SCAN_ERROR') {
      alert(`An error occurred: ${message.payload.error}`);
      setPanel(readyPanel);
    }
  });

  // Stop Scan Action
  btnCancel.addEventListener('click', () => {
    if (currentTab) {
      chrome.tabs.sendMessage(currentTab.id, { action: "CANCEL_SCAN" });
    }
    chrome.storage.local.remove('unfollow_spy_state');
    setPanel(readyPanel);
  });

  btnRestart.addEventListener('click', () => {
    chrome.storage.local.remove('unfollow_spy_state');
    setPanel(readyPanel);
  });

  // Dynamic filter niche options populator
  const updateNicheDropdown = () => {
    const currentSelection = filterNiche.value;
    filterNiche.innerHTML = '<option value="all">Filter Niche: All</option>';
    
    // Extract unique categories, sorted alphabetically
    const niches = [...new Set(finalUnfollowers.map(u => u.category).filter(Boolean))];
    niches.sort();
    
    niches.forEach(niche => {
      const option = document.createElement('option');
      option.value = niche;
      option.textContent = niche;
      filterNiche.appendChild(option);
    });

    if (niches.includes(currentSelection)) {
      filterNiche.value = currentSelection;
    } else {
      filterNiche.value = 'all';
    }
  };

  // Perform search, niche filtering, and list sorting
  const getFilteredAndSortedUsers = () => {
    let result = [...finalUnfollowers];

    // 1. Search Query Box
    const query = searchBox.value.toLowerCase().trim();
    if (query) {
      result = result.filter(u => 
        u.username.toLowerCase().includes(query) || 
        (u.full_name && u.full_name.toLowerCase().includes(query))
      );
    }

    // 2. Niche category filter
    const nicheValue = filterNiche.value;
    if (nicheValue !== 'all') {
      result = result.filter(u => u.category === nicheValue);
    }

    // 3. Sorting
    const sortValue = sortList.value;
    if (sortValue === 'username-asc') {
      result.sort((a, b) => a.username.localeCompare(b.username));
    } else if (sortValue === 'username-desc') {
      result.sort((a, b) => b.username.localeCompare(a.username));
    } else if (sortValue === 'type-private') {
      result.sort((a, b) => (b.is_private ? 1 : 0) - (a.is_private ? 1 : 0));
    } else if (sortValue === 'type-public') {
      result.sort((a, b) => (a.is_private ? 1 : 0) - (b.is_private ? 1 : 0));
    }

    return result;
  };

  // Trigger re-render on filter/sort changes
  searchBox.addEventListener('input', () => {
    renderUsers(getFilteredAndSortedUsers());
  });
  filterNiche.addEventListener('change', () => {
    renderUsers(getFilteredAndSortedUsers());
  });
  sortList.addEventListener('change', () => {
    renderUsers(getFilteredAndSortedUsers());
  });

  // Render list of unfollowers inside HTML popup
  const renderUsers = (users) => {
    usersListContainer.innerHTML = '';
    if (users.length === 0) {
      usersListContainer.innerHTML = `
        <div style="padding: 40px 20px; text-align: center; color: var(--text-muted); font-size: 13px;">
          🎉 <strong>No profiles found!</strong><br>Adjust your filters or query.
        </div>
      `;
      return;
    }

    users.forEach(user => {
      const row = document.createElement('div');
      row.className = 'user-row';

      const avatar = user.profile_pic_url || 'https://www.instagram.com/static/images/anonymousUser.jpg/7f7a63472c97.jpg';
      
      // Verified checkmark SVG
      const verifiedBadge = user.is_verified 
        ? `<svg style="width: 13px; height: 13px; fill: #3897f0; margin-left: 5px; vertical-align: middle; flex-shrink: 0;" viewBox="0 0 24 24" title="Verified"><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>`
        : '';

      // Profile type badges
      const profileTypeBadge = user.is_private
        ? `<span class="profile-type-badge badge-private">🔒 Private</span>`
        : `<span class="profile-type-badge badge-public">🌐 Public</span>`;

      const nicheBadge = user.category
        ? `<span class="profile-type-badge badge-niche" style="margin-left: 4px;">✨ ${user.category}</span>`
        : '';

      row.innerHTML = `
        <div class="user-info">
          <div class="avatar-container">
            <div class="avatar-ring"></div>
            <img class="user-avatar" src="${avatar}" referrerpolicy="no-referrer" onerror="this.src='https://www.instagram.com/static/images/anonymousUser.jpg/7f7a63472c97.jpg'">
          </div>
          <div class="user-details">
            <div style="display: flex; align-items: center; gap: 2px;">
              <a href="https://www.instagram.com/${user.username}/" class="user-username">@${user.username}</a>
              ${verifiedBadge}
            </div>
            <span class="user-fullname">${user.full_name || 'Instagram User'}</span>
            <div style="display: flex; flex-wrap: wrap; gap: 2px;">
              ${profileTypeBadge}
              ${nicheBadge}
            </div>
          </div>
        </div>
        <div style="display: flex; gap: 6px; align-items: center;">
          <a href="https://www.instagram.com/${user.username}/" class="btn-action btn-profile">Profile</a>
          <button class="btn-action btn-unfollow" data-id="${user.id}">Unfollow</button>
        </div>
      `;

      // Intercept profile link clicks to open in background tab
      row.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', (e) => {
          e.preventDefault();
          chrome.tabs.create({ url: link.href, active: false });
        });
      });

      // Handle unfollowing in real-time
      row.querySelector('.btn-unfollow').addEventListener('click', async (e) => {
        const button = e.currentTarget;
        const targetUserId = button.getAttribute('data-id');
        const oldText = button.textContent;

        button.disabled = true;
        button.textContent = 'Wait...';
        button.style.opacity = '0.7';

        chrome.tabs.sendMessage(currentTab.id, {
          action: "UNFOLLOW_USER",
          targetUserId: targetUserId,
          csrfToken: csrfToken
        }, async (response) => {
          if (chrome.runtime.lastError || !response || !response.success) {
            const errorMsg = (response && response.error) || (chrome.runtime.lastError ? chrome.runtime.lastError.message : "Request failed");
            alert(`Could not unfollow: ${errorMsg}`);
            button.disabled = false;
            button.textContent = oldText;
            button.style.opacity = '1';
          } else {
            // Success: Remove user from our active list
            finalUnfollowers = finalUnfollowers.filter(u => u.id !== targetUserId);

            // Update persistent storage
            const stored = await chrome.storage.local.get('unfollow_spy_state');
            if (stored.unfollow_spy_state) {
              stored.unfollow_spy_state.unfollowers = finalUnfollowers;
              await chrome.storage.local.set({ unfollow_spy_state: stored.unfollow_spy_state });
            }

            // Real-time stats recalculation
            unfollowersCount.textContent = finalUnfollowers.length;
            const followingCount = parseInt(statFollowing.textContent) || 0;
            statMutual.textContent = Math.max(followingCount - finalUnfollowers.length, 0);

            // Slide out and remove the row
            row.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
            row.style.opacity = '0';
            row.style.transform = 'translateX(24px)';
            
            setTimeout(() => {
              row.remove();
              if (finalUnfollowers.length === 0) {
                renderUsers([]); // Render empty state
              }
            }, 300);
          }
        });
      });

      usersListContainer.appendChild(row);
    });
  };

  // Dynamic on-demand category niches fetcher
  btnFetchCategories.addEventListener('click', async () => {
    const countToFetch = finalUnfollowers.filter(u => !u.category).length;
    if (countToFetch === 0) {
      alert("Niches / Categories for all profiles in the list are already loaded!");
      return;
    }

    const confirmRun = confirm(
      `This will fetch the category/niche (e.g. Digital Creator, Clothing Brand, blogger etc.) for the ${countToFetch} remaining profiles.\n\n` +
      `To keep your Instagram account safe from rate checks, requests are safely paced with a 1.5 - 2s delay. This will take about ${Math.ceil(countToFetch * 1.8)} seconds.\n\n` +
      `Do you want to proceed?`
    );

    if (!confirmRun) return;

    btnFetchCategories.style.display = 'none';
    const progressContainer = document.getElementById('category-progress-container');
    const progressBar = document.getElementById('category-progress-bar');
    const progressStats = document.getElementById('category-progress-stats');
    progressContainer.style.display = 'flex';

    let successCount = 0;
    for (let i = 0; i < finalUnfollowers.length; i++) {
      const user = finalUnfollowers[i];
      if (user.category) continue; // Already loaded

      progressStats.textContent = `${successCount} / ${countToFetch}`;
      const percent = (successCount / countToFetch) * 100;
      progressBar.style.width = `${percent}%`;

      try {
        const response = await new Promise((resolve, reject) => {
          chrome.tabs.sendMessage(currentTab.id, {
            action: "FETCH_CATEGORY",
            username: user.username,
            csrfToken: csrfToken
          }, (res) => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve(res);
            }
          });
        });

        if (response && response.success) {
          user.category = response.category || "Personal Profile";
          successCount++;

          // Save incrementally to storage (survives popup closes)
          const stored = await chrome.storage.local.get('unfollow_spy_state');
          if (stored.unfollow_spy_state) {
            stored.unfollow_spy_state.unfollowers = finalUnfollowers;
            await chrome.storage.local.set({ unfollow_spy_state: stored.unfollow_spy_state });
          }

          // Update UI in real-time
          updateNicheDropdown();
          renderUsers(getFilteredAndSortedUsers());
        }
      } catch (err) {
        console.error(`Error loading category for @${user.username}:`, err);
      }

      // Safety delay with jitter
      await sleep(1500 + Math.random() * 500);
    }

    progressContainer.style.display = 'none';
    btnFetchCategories.style.display = 'block';
  });

  // Copy names to clipboard helper
  btnCopy.addEventListener('click', async () => {
    if (finalUnfollowers.length === 0) return;
    const usernamesStr = finalUnfollowers.map(u => `@${u.username}`).join('\n');
    
    try {
      await navigator.clipboard.writeText(usernamesStr);
      const oldText = btnCopy.textContent;
      btnCopy.textContent = '📋 Copied!';
      btnCopy.style.borderColor = 'var(--success-color)';
      btnCopy.style.color = 'var(--success-color)';
      setTimeout(() => {
        btnCopy.textContent = oldText;
        btnCopy.style.borderColor = 'var(--border-color)';
        btnCopy.style.color = 'var(--text-main)';
      }, 1500);
    } catch (err) {
      console.error('Could not copy text via clipboard API', err);
      // Fallback method
      const textArea = document.createElement("textarea");
      textArea.value = usernamesStr;
      document.body.appendChild(textArea);
      textArea.select();
      try {
        document.execCommand('copy');
        const oldText = btnCopy.textContent;
        btnCopy.textContent = '📋 Copied!';
        btnCopy.style.borderColor = 'var(--success-color)';
        btnCopy.style.color = 'var(--success-color)';
        setTimeout(() => {
          btnCopy.textContent = oldText;
          btnCopy.style.borderColor = 'var(--border-color)';
          btnCopy.style.color = 'var(--text-main)';
        }, 1500);
      } catch (err2) {
        console.error('Fallback copy failed', err2);
      }
      document.body.removeChild(textArea);
    }
  });

  // Export as CSV with UTF-8 BOM
  btnExportCsv.addEventListener('click', () => {
    if (finalUnfollowers.length === 0) return;
    let csvContent = "\ufeffUsername,Full Name,User ID,Profile URL,Profile Niche / Category\n";
    
    finalUnfollowers.forEach(user => {
      const row = [
        user.username,
        `"${(user.full_name || '').replace(/"/g, '""')}"`,
        user.id,
        `https://www.instagram.com/${user.username}/`,
        `"${user.category || 'Not Loaded'}"`
      ].join(",");
      csvContent += row + "\n";
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `instagram_non_followers_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  });

  // Self execute status checks and restore state on startup
  const initializePopup = async () => {
    const isReady = await checkStatus();
    
    // Only check background state if active on Instagram page
    if (isReady) {
      const stored = await chrome.storage.local.get('unfollow_spy_state');
      if (stored.unfollow_spy_state) {
        const stateData = stored.unfollow_spy_state;
        
        if (stateData.status === 'running') {
          setPanel(progressPanel);
          
          if (stateData.phase === 'following') {
            const percent = stateData.total ? Math.min((stateData.count / stateData.total) * 100, 100) : 50;
            followingBar.style.width = `${percent}%`;
            followingStats.textContent = `${stateData.count}${stateData.total ? ' / ' + stateData.total : ''}`;
            followingStatus.textContent = `🔄 Fetching page (batch size: ${stateData.currentBatch || 0})...`;
          } else if (stateData.phase === 'followers') {
            // Step 1 following is finished
            followingBar.style.width = '100%';
            followingStats.textContent = 'Done';
            followingStatus.textContent = '✅ Scrape complete.';

            // Step 2 followers is active
            const percent = stateData.total ? Math.min((stateData.count / stateData.total) * 100, 100) : 50;
            followersBar.style.width = `${percent}%`;
            followersStats.textContent = `${stateData.count}${stateData.total ? ' / ' + stateData.total : ''}`;
            followersStatus.textContent = `🔄 Fetching page (batch size: ${stateData.currentBatch || 0})...`;
          }
        } else if (stateData.status === 'complete') {
          finalUnfollowers = stateData.unfollowers || [];
          const followingCount = stateData.followingCount || 0;
          const followersCount = stateData.followersCount || 0;

          unfollowersCount.textContent = finalUnfollowers.length;
          statFollowing.textContent = followingCount;
          statMutual.textContent = Math.max(followingCount - finalUnfollowers.length, 0);

          updateNicheDropdown();
          renderUsers(getFilteredAndSortedUsers());
          setPanel(resultsPanel);
        } else if (stateData.status === 'error') {
          chrome.storage.local.remove('unfollow_spy_state');
          alert(`Scanner encountered an error during background run: ${stateData.error}`);
          setPanel(readyPanel);
        }
      }
    }
  };

  initializePopup();
});

// Listening to calls from popup
let abortController = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "START_SCAN") {
    abortController = new AbortController();
    runMainScanner(message.userId, message.csrfToken, message.delay, abortController.signal);
    sendResponse({ started: true });
  } else if (message.action === "CANCEL_SCAN") {
    if (abortController) {
      abortController.abort();
    }
  } else if (message.action === "UNFOLLOW_USER") {
    executeUnfollow(message.targetUserId, message.csrfToken)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true; // Keep message channel open for async response
  } else if (message.action === "FETCH_CATEGORY") {
    fetchCategory(message.username, message.csrfToken)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true; // Keep message channel open for async response
  }
  return true; // Keep message channel open
});

// Sleep utility to respect rate limits
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

async function fetchCategory(username, csrfToken) {
  const url = `https://www.instagram.com/api/v1/users/web_profile_info/?username=${username}`;
  
  const headers = {
    "x-ig-app-id": "936619743392459", // Tells Instagram we are the official client
    "x-requested-with": "XMLHttpRequest"
  };

  if (csrfToken) {
    headers["x-csrftoken"] = csrfToken;
  }

  const response = await fetch(url, {
    method: "GET",
    headers: headers
  });

  if (!response.ok) {
    if (response.status === 429) {
      throw new Error("Instagram Rate-Limit triggered. Please wait a few minutes.");
    }
    throw new Error(`Instagram server returned code ${response.status}`);
  }

  const data = await response.json();
  if (data.status === "ok" && data.data && data.data.user) {
    const user = data.data.user;
    return {
      success: true,
      category: user.category_name || "Personal Profile",
      is_business: !!user.is_business_account,
      is_professional: !!user.is_professional_account
    };
  } else {
    throw new Error("Could not parse profile info.");
  }
}

async function executeUnfollow(targetUserId, csrfToken) {
  const url = `https://www.instagram.com/api/v1/friendships/destroy/${targetUserId}/`;
  
  const headers = {
    "x-ig-app-id": "936619743392459", // Web client app ID
    "x-requested-with": "XMLHttpRequest",
    "content-type": "application/x-www-form-urlencoded"
  };

  if (csrfToken) {
    headers["x-csrftoken"] = csrfToken;
  }

  const response = await fetch(url, {
    method: "POST",
    headers: headers,
    body: "container_module=default"
  });

  if (!response.ok) {
    throw new Error(`Instagram server returned code ${response.status} during unfollow.`);
  }

  const data = await response.json();
  if (data.status === "ok") {
    return { success: true };
  } else {
    throw new Error(data.message || "Failed to unfollow user.");
  }
}

async function runMainScanner(userId, csrfToken, delayMs, signal) {
  try {
    // Initialise background scan state in local storage
    chrome.storage.local.set({
      unfollow_spy_state: {
        status: 'running',
        phase: 'following',
        count: 0,
        total: 0,
        state: 'running'
      }
    });

    // 1. Fetch Following
    const following = await fetchList('following', userId, csrfToken, delayMs, signal);
    if (signal.aborted) return;

    // 2. Fetch Followers
    const followers = await fetchList('followers', userId, csrfToken, delayMs, signal);
    if (signal.aborted) return;

    // 3. Compute Unfollowers (Users I follow but they do not follow me back)
    const followersSet = new Set(followers.map(f => f.id));
    const unfollowers = following.filter(user => !followersSet.has(user.id));

    // Save final complete state to local storage (survives popup closes)
    chrome.storage.local.set({
      unfollow_spy_state: {
        status: 'complete',
        unfollowers,
        followingCount: following.length,
        followersCount: followers.length
      }
    });

    // Broadcast scan complete in case popup is active
    chrome.runtime.sendMessage({
      type: 'SCAN_COMPLETE',
      payload: {
        unfollowers,
        followingCount: following.length,
        followersCount: followers.length
      }
    });

  } catch (error) {
    if (signal.aborted) {
      console.log("Scanner gracefully stopped by user choice.");
      chrome.storage.local.remove('unfollow_spy_state');
      return;
    }
    
    console.error("Unfollow Scanner caught Error:", error);
    
    // Save error state to local storage
    chrome.storage.local.set({
      unfollow_spy_state: {
        status: 'error',
        error: error.message
      }
    });

    // Broadcast error
    chrome.runtime.sendMessage({
      type: 'SCAN_ERROR',
      payload: { error: error.message }
    });
  }
}

async function fetchList(listType, userId, csrfToken, delayMs, signal) {
  let allUsers = [];
  let nextMaxId = "";
  let hasMore = true;

  while (hasMore) {
    if (signal.aborted) return [];

    let url = `https://www.instagram.com/api/v1/friendships/${userId}/${listType}/?count=100`;
    if (nextMaxId) {
      url += `&max_id=${nextMaxId}`;
    }

    const headers = {
      "x-ig-app-id": "936619743392459", // Tells Instagram we are the official client
      "x-requested-with": "XMLHttpRequest"
    };

    if (csrfToken) {
      headers["x-csrftoken"] = csrfToken;
    }

    const response = await fetch(url, {
      method: "GET",
      signal: signal,
      headers: headers
    });

    if (!response.ok) {
      if (response.status === 429) {
        throw new Error("Instagram Rate-Limit triggered. Please wait 15 minutes and run again with a larger request delay.");
      }
      throw new Error(`Instagram server returned code ${response.status}. Try logging out and back in on your tab.`);
    }

    const data = await response.json();
    const batch = data.users || [];
    allUsers = allUsers.concat(batch);

    const progressPayload = {
      phase: listType,
      count: allUsers.length,
      total: listType === 'following' ? data.following_count : data.followers_count,
      currentBatch: batch.length,
      state: 'running'
    };

    // Keep storage updated with current batch counts
    chrome.storage.local.set({
      unfollow_spy_state: {
        status: 'running',
        ...progressPayload
      }
    });

    // Send runtime message (if popup is active)
    chrome.runtime.sendMessage({
      type: 'PROGRESS_UPDATE',
      payload: progressPayload
    });

    nextMaxId = data.next_max_id;
    hasMore = !!nextMaxId;

    if (hasMore) {
      // Respectful pacing pause to mimic human activity
      await sleep(delayMs + (Math.random() * 500));
    }
  }

  const completePayload = {
    phase: listType,
    count: allUsers.length,
    state: 'complete'
  };

  // Update storage with page completion
  chrome.storage.local.set({
    unfollow_spy_state: {
      status: 'running',
      ...completePayload
    }
  });

  // Notify finished list state
  chrome.runtime.sendMessage({
    type: 'PROGRESS_UPDATE',
    payload: completePayload
  });

  return allUsers;
}

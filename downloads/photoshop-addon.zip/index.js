const { app, core } = require('photoshop');
const { batchPlay } = require('photoshop').action;

// UI Elements
const btnConvert = document.getElementById("btn-convert");
const btnAdjustRange = document.getElementById("btn-adjust-range");
const btnUpdateCopies = document.getElementById("btn-update-copies");
const btnUpdateNoise = document.getElementById("btn-update-noise");
const statusMessage = document.getElementById("status-message");
const mgmtArea = document.getElementById("mgmt-area");

const copyCountInput = document.getElementById("copy-count");
const updateCopyCountInput = document.getElementById("update-copy-count");
const noiseAmountInput = document.getElementById("noise-amount");
const noiseDistributionInput = document.getElementById("noise-distribution");
const noiseMonoInput = document.getElementById("noise-mono");

// Helper to show status message
function showStatus(text, type = "info") {
    statusMessage.innerText = text;
    statusMessage.className = type;
    statusMessage.style.display = text ? "block" : "none";
}

// Helper to find a layer recursively by name
function findLayerByName(name, container = app.activeDocument) {
    if (!container || !container.layers) return null;
    for (const layer of container.layers) {
        if (layer.name === name) return layer;
        if (layer.kind === 'GROUP') {
            const found = findLayerByName(name, layer);
            if (found) return found;
        }
    }
    return null;
}

// Wrapper for executeAsModal
async function runModal(fn, name) {
    try {
        await core.executeAsModal(fn, { commandName: name });
        return true;
    } catch (e) {
        console.error(e);
        showStatus(`Error: ${e.message || e}`, "error");
        return false;
    }
}

// --- batchPlay Action Descriptors ---

async function runColorRangeDialog() {
    await batchPlay([
        {
            _obj: "colorRange",
            _options: { dialogOptions: "display" }
        }
    ], {});
}

async function createInvertAdjustmentLayer() {
    await batchPlay([
        {
            _obj: "make",
            _target: [{ _ref: "adjustmentLayer", _class: "invert" }]
        }
    ], {});
}

async function makeClippingMask() {
    await batchPlay([
        {
            _obj: "makeGrouping",
            _target: [{ _ref: "layer", _enum: "ordinal", _value: "targetEnum" }]
        }
    ], {});
}

async function createMaskFromSelection() {
    await batchPlay([
        {
            _obj: "make",
            new: { _class: "mask" },
            using: { _enum: "userMaskEnabled", _value: "revealSelection" }
        }
    ], {});
}

async function deleteLayerMask() {
    await batchPlay([
        {
            _obj: "delete",
            _target: [{ _ref: "channel", _enum: "channel", _value: "mask" }],
            discard: true
        }
    ], {});
}

async function loadMaskAsSelection() {
    await batchPlay([
        {
            _obj: "set",
            _target: [{ _ref: "channel", _property: "selection" }],
            to: { _ref: "channel", _enum: "channel", _value: "mask" }
        }
    ], {});
}

async function groupSelectedLayers() {
    await batchPlay([
        {
            _obj: "make",
            _target: [{ _ref: "layerSection" }],
            from: { _ref: "layer", _enum: "ordinal", _value: "targetEnum" }
        }
    ], {});
}

async function convertActiveLayerToSmartObject() {
    await batchPlay([
        {
            _obj: "newPlacedLayer"
        }
    ], {});
}

async function duplicateActiveLayer() {
    await batchPlay([
        {
            _obj: "duplicate",
            _target: [{ _ref: "layer", _enum: "ordinal", _value: "targetEnum" }]
        }
    ], {});
}

async function applyNoiseFilter(amount, distribution, monochromatic) {
    await batchPlay([
        {
            _obj: "noise",
            _options: { dialogOptions: "dontDisplay" },
            distribution: { _enum: "distribution", _value: distribution },
            grain: amount,
            monochromatic: monochromatic
        }
    ], {});
}

async function createGradientMap() {
    await batchPlay([
        {
            _obj: "make",
            _target: [{ _ref: "adjustmentLayer", _class: "gradientMapClass" }],
            _options: { dialogOptions: "display" }
        }
    ], {});
}

// --- Main Operations ---

// 1. Initial Conversion
async function runConvert() {
    const doc = app.activeDocument;
    if (!doc) {
        showStatus("Please open an image first.", "error");
        return;
    }

    if (doc.activeLayers.length === 0) {
        showStatus("Please select an image layer first.", "error");
        return;
    }

    const copies = parseInt(copyCountInput.value) || 3;
    showStatus("Processing...", "info");

    const success = await runModal(async () => {
        // Step A: Duplicate original selected layer and convert it to Smart Object
        const originalLayer = doc.activeLayers[0];
        
        // Duplicate active layer
        await duplicateActiveLayer();
        const baseSmartObject = doc.activeLayers[0];
        await convertActiveLayerToSmartObject();
        baseSmartObject.name = "Base Image (Smart Object)";

        // Step B: Trigger Color Range dialog
        try {
            await runColorRangeDialog();
        } catch (e) {
            // Cancelled
            baseSmartObject.delete();
            showStatus("Color Range selection cancelled.", "info");
            return;
        }

        // Check if there is an active selection
        if (doc.selection.bounds === null) {
            baseSmartObject.delete();
            showStatus("No color range was selected. Process aborted.", "error");
            return;
        }

        const effectGroups = [];

        // Step C: Repeat N times - duplicates and clipped invert layers
        for (let i = 1; i <= copies; i++) {
            // Select Base Smart Object
            doc.activeLayers = [baseSmartObject];
            
            // Duplicate it
            await duplicateActiveLayer();
            const copyLayer = doc.activeLayers[0];
            copyLayer.name = `Selection Source Copy ${i}`;

            // Create Mask from active selection
            await createMaskFromSelection();

            // Create Invert adjustment layer above it
            await createInvertAdjustmentLayer();
            const invertLayer = doc.activeLayers[0];
            invertLayer.name = `Invert Map ${i}`;

            // Clip Invert layer to Selection Copy layer
            await makeClippingMask();

            // Group them
            doc.activeLayers = [invertLayer, copyLayer];
            await groupSelectedLayers();
            const group = doc.activeLayers[0];
            group.name = `Effect Group ${i}`;
            effectGroups.push(group);
        }

        // Step D: Create Smart Noise Layer above top-most Effect Group
        doc.activeLayers = [effectGroups[effectGroups.length - 1]];
        
        await batchPlay([
            {
                _obj: "make",
                _target: [{ _ref: "layer" }],
                using: {
                    _obj: "layer",
                    name: "Noise Layer",
                    fill: { _enum: "fillColor", _value: "neutralGray" },
                    mode: { _enum: "blendMode", _value: "overlay" }
                }
            }
        ], {});
        
        const noiseLayer = doc.activeLayers[0];
        await convertActiveLayerToSmartObject();
        noiseLayer.name = "Noise Layer";
        
        // Read defaults
        const noiseAmt = parseInt(noiseAmountInput.value) || 5;
        const noiseDist = noiseDistributionInput.value || "uniform";
        const noiseMono = noiseMonoInput.checked;
        await applyNoiseFilter(noiseAmt, noiseDist, noiseMono);

        // Step E: Create Gradient Map above Noise Layer
        doc.activeLayers = [noiseLayer];
        try {
            await createGradientMap();
        } catch (e) {
            // User might cancel the gradient map dialog; we still keep the layer
        }
        const gradLayer = doc.activeLayers[0];
        gradLayer.name = "Master Gradient Map";

        // Step F: Group everything inside the master folder "[Invert Noise Effect]"
        const layersToGroup = [gradLayer, noiseLayer, ...[...effectGroups].reverse(), baseSmartObject];
        doc.activeLayers = layersToGroup;
        await groupSelectedLayers();
        doc.activeLayers[0].name = "[Invert Noise Effect]";

        // Clear active selection on screen
        doc.selection.deselect();

        // Sync slider values in panel
        updateCopyCountInput.value = copies;
        mgmtArea.classList.add("active");
        showStatus("Conversion completed successfully!", "success");

    }, "Convert Image");
}

// 2. Adjust Color Range
async function adjustColorRange() {
    const doc = app.activeDocument;
    if (!doc) return;

    // Find the first selection copy layer to load the existing mask
    const firstCopy = findLayerByName("Selection Source Copy 1");
    if (!firstCopy) {
        showStatus("Could not find base selection copies. Please run convert first.", "error");
        return;
    }

    const baseSmartObject = findLayerByName("Base Image (Smart Object)");
    if (!baseSmartObject) {
        showStatus("Could not find Base Image Smart Object.", "error");
        return;
    }

    showStatus("Adjusting color range...", "info");

    await runModal(async () => {
        // Load the mask as selection
        doc.activeLayers = [firstCopy];
        await loadMaskAsSelection();

        // Select the base smart object to run color range on original colors
        doc.activeLayers = [baseSmartObject];

        try {
            await runColorRangeDialog();
        } catch (e) {
            doc.selection.deselect();
            showStatus("Adjustment cancelled.", "info");
            return;
        }

        if (doc.selection.bounds === null) {
            doc.selection.deselect();
            showStatus("No color range selected.", "info");
            return;
        }

        // Loop through all existing selection copy layers and update their masks
        let i = 1;
        let copyLayer;
        while ((copyLayer = findLayerByName(`Selection Source Copy ${i}`)) !== null) {
            doc.activeLayers = [copyLayer];
            try {
                await deleteLayerMask();
            } catch (e) {}
            await createMaskFromSelection();
            i++;
        }

        doc.selection.deselect();
        showStatus("Color range selection updated successfully!", "success");

    }, "Adjust Color Range");
}

// 3. Update Copy Count
async function updateCopyCount() {
    const doc = app.activeDocument;
    if (!doc) return;

    const baseSmartObject = findLayerByName("Base Image (Smart Object)");
    if (!baseSmartObject) {
        showStatus("Could not find Base Image Smart Object.", "error");
        return;
    }

    const firstCopy = findLayerByName("Selection Source Copy 1");
    if (!firstCopy) {
        showStatus("Could not find selection copies. Please run convert first.", "error");
        return;
    }

    const newCount = parseInt(updateCopyCountInput.value) || 3;
    showStatus("Updating copy count...", "info");

    await runModal(async () => {
        // Load the current mask as selection
        doc.activeLayers = [firstCopy];
        await loadMaskAsSelection();

        // Delete all old effect groups
        let i = 1;
        let group;
        while ((group = findLayerByName(`Effect Group ${i}`)) !== null) {
            group.delete();
            i++;
        }

        const effectGroups = [];

        // Recreate new copies inside the master group
        for (let j = 1; j <= newCount; j++) {
            doc.activeLayers = [baseSmartObject];
            await duplicateActiveLayer();
            const copyLayer = doc.activeLayers[0];
            copyLayer.name = `Selection Source Copy ${j}`;

            await createMaskFromSelection();

            await createInvertAdjustmentLayer();
            const invertLayer = doc.activeLayers[0];
            invertLayer.name = `Invert Map ${j}`;

            await makeClippingMask();

            doc.activeLayers = [invertLayer, copyLayer];
            await groupSelectedLayers();
            const group = doc.activeLayers[0];
            group.name = `Effect Group ${j}`;
            effectGroups.push(group);
        }

        doc.selection.deselect();
        showStatus(`Successfully updated to ${newCount} copies!`, "success");

    }, "Update Copy Count");
}

// 4. Update Noise settings
async function updateNoiseSettings() {
    const doc = app.activeDocument;
    if (!doc) return;

    const noiseLayer = findLayerByName("Noise Layer");
    if (!noiseLayer) {
        showStatus("Could not find Noise Layer.", "error");
        return;
    }

    const amt = parseInt(noiseAmountInput.value) || 5;
    const dist = noiseDistributionInput.value || "uniform";
    const mono = noiseMonoInput.checked;

    showStatus("Updating noise settings...", "info");

    await runModal(async () => {
        // Select the Noise Layer Smart Object and re-apply the filter
        doc.activeLayers = [noiseLayer];
        await applyNoiseFilter(amt, dist, mono);
        showStatus("Noise settings updated successfully!", "success");
    }, "Update Noise Settings");
}

// --- Event Listeners ---
btnConvert.addEventListener("click", runConvert);
btnAdjustRange.addEventListener("click", adjustColorRange);
btnUpdateCopies.addEventListener("click", updateCopyCount);
btnUpdateNoise.addEventListener("click", updateNoiseSettings);

const { app, BrowserWindow, globalShortcut, ipcMain, desktopCapturer, screen, Tray, Menu, shell, protocol, net } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn, exec } = require('child_process');
const { pathToFileURL } = require('url');

// Register custom scheme for TrackXpense
protocol.registerSchemesAsPrivileged([
  { scheme: 'trackxpense', privileges: { standard: true, secure: true, supportFetchAPI: true } }
]);

let commandBarWindow = null;
let settingsWindow = null;
let tray = null;
let configPath = path.join(__dirname, 'configuration.json');

// Default config fallback
const defaultConfig = {
  hotkey: "ctrl+shift+space",
  default_projects_dir: "",
  softwares: {
    "Blender": { "exec_path": "C:\\Program Files\\Blender Foundation\\Blender 4.2\\blender.exe", "icon_color": "#E87D0D", "default_dir": "" },
    "Photoshop": { "exec_path": "C:\\Program Files\\Adobe\\Adobe Photoshop 2024\\Photoshop.exe", "icon_color": "#31A8FF", "default_dir": "" },
    "VS Code": { "exec_path": "code", "icon_color": "#007ACC", "default_dir": "" }
  },
  projects: [
    { "name": "Sci-Fi Mech Render", "software": "Blender", "path": "", "description": "Blender cycles model workspace." }
  ],
  distractions: ["chrome.exe", "msedge.exe", "firefox.exe", "discord.exe", "steam.exe"],
  reminders: []
};

// Helper: Read configuration file safely
function loadConfig() {
  try {
    if (fs.existsSync(configPath)) {
      const data = fs.readFileSync(configPath, 'utf8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading config file:', err);
  }
  return defaultConfig;
}

// Helper: Write configuration file safely
function saveConfig(config) {
  try {
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error('Error writing config file:', err);
    return false;
  }
}

// Create the Command Bar overlay window (transparent, borderless, full-screen)
function createCommandBarWindow() {
  const primaryDisplay = screen.getPrimaryDisplay();
  const { width, height } = primaryDisplay.bounds;

  commandBarWindow = new BrowserWindow({
    x: 0,
    y: 0,
    width,
    height,
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    skipTaskbar: true,
    show: false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  commandBarWindow.loadFile(path.join(__dirname, 'commandbar.html'));

  // Prevent app from quitting if window is closed manually (e.g. by DevTools)
  commandBarWindow.on('close', (e) => {
    if (!app.isQuiting) {
      e.preventDefault();
      commandBarWindow.hide();
    }
  });
}

// Create the Settings GUI Dashboard window
function createSettingsWindow() {
  settingsWindow = new BrowserWindow({
    width: 780,
    height: 580,
    minWidth: 700,
    minHeight: 500,
    show: true,
    frame: false, // frameless window for custom titlebar
    title: "aegis",
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  // Hide the default File/Edit/View menu bar
  settingsWindow.setMenu(null);

  settingsWindow.loadFile(path.join(__dirname, 'settings.html'));

  // Notify renderer of maximize/unmaximize state for custom titlebar icons
  settingsWindow.on('maximize', () => {
    settingsWindow.webContents.send('window-maximized-status', true);
  });
  settingsWindow.on('unmaximize', () => {
    settingsWindow.webContents.send('window-maximized-status', false);
  });

  // Closing the window only hides it to keep background process alive
  settingsWindow.on('close', (e) => {
    if (!app.isQuiting) {
      e.preventDefault();
      settingsWindow.hide();
    }
  });
}

// Create the TrackXpense Ledger window
let ledgerWindow = null;
function openLedgerWindow() {
  if (ledgerWindow) {
    ledgerWindow.show();
    ledgerWindow.focus();
    return;
  }

  ledgerWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 800,
    minHeight: 600,
    frame: true,
    title: "TrackXpense Ledger",
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  ledgerWindow.setMenu(null);
  ledgerWindow.loadURL('trackxpense://app/index.html');

  ledgerWindow.on('closed', () => {
    ledgerWindow = null;
  });
}

// Toggle command bar summons with screenshot backdrop capture
function toggleCommandBar() {
  if (!commandBarWindow) return;
  
  if (commandBarWindow.isVisible()) {
    commandBarWindow.hide();
  } else {
    const primaryDisplay = screen.getPrimaryDisplay();
    const { width, height } = primaryDisplay.bounds;

    desktopCapturer.getSources({
      types: ['screen'],
      thumbnailSize: { width: Math.floor(width / 2), height: Math.floor(height / 2) }
    }).then(sources => {
      if (sources.length > 0) {
        const imgData = sources[0].thumbnail.toDataURL();
        commandBarWindow.webContents.send('bg-captured', imgData);
      }
      commandBarWindow.show();
      commandBarWindow.focus();
      commandBarWindow.webContents.send('focus-input');
    }).catch(err => {
      console.error('Failed to capture screen:', err);
      commandBarWindow.show();
      commandBarWindow.focus();
      commandBarWindow.webContents.send('focus-input');
    });
  }
}

// Global hotkey registration helper
function registerHotkey(hotkeyStr) {
  try {
    globalShortcut.unregisterAll();
    const shortcut = hotkeyStr || 'ctrl+shift+space';
    globalShortcut.register(shortcut, () => {
      toggleCommandBar();
    });
  } catch (err) {
    console.error('Failed to register global hotkey:', err);
  }
}

// ----------------------------------------------------
// Deep Focus Mode (Process killer loop)
// ----------------------------------------------------
let focusInterval = null;

function startFocusMode() {
  if (focusInterval) clearInterval(focusInterval);
  killDistractions();
  focusInterval = setInterval(killDistractions, 5000);
}

function stopFocusMode() {
  if (focusInterval) {
    clearInterval(focusInterval);
    focusInterval = null;
  }
}

function killDistractions() {
  const config = loadConfig();
  const distractions = config.distractions || [];
  distractions.forEach(appProcess => {
    exec(`taskkill /F /IM "${appProcess}"`, (err) => {
      // Silently fail if process is not running
    });
  });
}

// ----------------------------------------------------
// Reminders Scheduler & Timers
// ----------------------------------------------------
let activeTimers = {};

function notifyRemindersUpdated() {
  if (commandBarWindow) commandBarWindow.webContents.send('reminders-updated');
  if (settingsWindow) settingsWindow.webContents.send('reminders-updated');
}

// ----------------------------------------------------
// IPC Listeners & Handlers Setup
// ----------------------------------------------------
function setupIpc() {
  // Configuration management
  ipcMain.handle('get-config', () => {
    return loadConfig();
  });

  ipcMain.handle('save-config', (event, newConfig) => {
    const success = saveConfig(newConfig);
    if (success && newConfig.hotkey) {
      registerHotkey(newConfig.hotkey);
    }
    return success;
  });

  // Windows commands
  ipcMain.on('open-settings', () => {
    if (settingsWindow) {
      settingsWindow.show();
      settingsWindow.focus();
    }
  });

  ipcMain.on('hide-commandbar', () => {
    if (commandBarWindow) {
      commandBarWindow.hide();
    }
  });

  ipcMain.on('window-minimize', (event) => {
    const win = BrowserWindow.fromWebContents(event.sender);
    if (win) win.minimize();
  });

  ipcMain.on('window-maximize', (event) => {
    const win = BrowserWindow.fromWebContents(event.sender);
    if (win) {
      if (win.isMaximized()) {
        win.unmaximize();
      } else {
        win.maximize();
      }
    }
  });

  ipcMain.on('window-close', (event) => {
    const win = BrowserWindow.fromWebContents(event.sender);
    if (win) {
      if (win === settingsWindow) {
        if (!app.isQuiting) {
          win.hide();
        } else {
          win.close();
        }
      } else {
        win.close();
      }
    }
  });

  ipcMain.on('exit-app', () => {
    app.isQuiting = true;
    app.quit();
  });

  // Launching Workspace project
  ipcMain.handle('launch-project', (event, projectName) => {
    const config = loadConfig();
    const proj = config.projects.find(p => p.name === projectName);
    if (!proj) return { success: false, error: 'Project not found' };

    const sw = config.softwares[proj.software];
    if (!sw) return { success: false, error: `Software "${proj.software}" not configured` };

    const execPath = sw.exec_path;
    const projectPath = proj.path;

    if (!execPath) return { success: false, error: 'Executable path is empty' };

    // Support standard VS Code shortcut command
    if (execPath.toLowerCase() === 'code' || execPath.toLowerCase() === 'code.cmd') {
      exec(`code "${projectPath}"`, (err) => {
        if (err) console.error('Failed to launch VS Code:', err);
      });
      return { success: true };
    }

    try {
      const child = spawn(execPath, [projectPath], {
        detached: true,
        stdio: 'ignore'
      });
      child.unref();
      return { success: true };
    } catch (err) {
      console.error('Failed to spawn software process:', err);
      return { success: false, error: err.message };
    }
  });

  // Deep Focus Mode toggle
  ipcMain.handle('toggle-focus', () => {
    const active = focusInterval !== null;
    if (active) {
      stopFocusMode();
      if (commandBarWindow) commandBarWindow.webContents.send('focus-status', false);
      if (settingsWindow) settingsWindow.webContents.send('focus-status', false);
      return false;
    } else {
      startFocusMode();
      if (commandBarWindow) commandBarWindow.webContents.send('focus-status', true);
      if (settingsWindow) settingsWindow.webContents.send('focus-status', true);
      return true;
    }
  });

  // Get current Focus Mode status
  ipcMain.handle('get-focus-status', () => {
    return focusInterval !== null;
  });

  // Reminders Management
  ipcMain.handle('add-reminder', (event, type, text, mins) => {
    const config = loadConfig();
    const id = 'rem_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);

    const reminder = {
      id,
      type,
      text,
      duration: mins,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + mins * 60 * 1000).toISOString(),
      status: 'active'
    };

    config.reminders = config.reminders || [];
    config.reminders.push(reminder);
    saveConfig(config);

    const timeoutMs = mins * 60 * 1000;
    const timerId = setTimeout(() => {
      const currentConfig = loadConfig();
      const rIndex = currentConfig.reminders.findIndex(r => r.id === id);
      if (rIndex >= 0 && currentConfig.reminders[rIndex].status === 'active') {
        currentConfig.reminders[rIndex].status = 'completed';
        saveConfig(currentConfig);

        // System Notification alert
        const { Notification } = require('electron');
        if (Notification.isSupported()) {
          new Notification({
            title: type === 'timer' ? 'A.E.G.I.S. Focus Completed' : 'A.E.G.I.S. Reminder',
            body: text,
            silent: false
          }).show();
        }
        notifyRemindersUpdated();
      }
      delete activeTimers[id];
    }, timeoutMs);

    activeTimers[id] = timerId;
    notifyRemindersUpdated();

    return reminder;
  });

  ipcMain.handle('cancel-reminder', (event, id) => {
    const config = loadConfig();
    const rIndex = config.reminders.findIndex(r => r.id === id);
    if (rIndex >= 0) {
      config.reminders[rIndex].status = 'cancelled';
      saveConfig(config);

      if (activeTimers[id]) {
        clearTimeout(activeTimers[id]);
        delete activeTimers[id];
      }
      notifyRemindersUpdated();
      return true;
    }
    return false;
  });

  ipcMain.handle('clear-reminder-history', () => {
    const config = loadConfig();
    config.reminders = config.reminders.filter(r => r.status === 'active');
    saveConfig(config);
    notifyRemindersUpdated();
    return true;
  });

  // Audio Control Bridge
  ipcMain.on('audio-control', (event, args) => {
    if (commandBarWindow) {
      commandBarWindow.webContents.send('audio-control', args);
    }
  });

  ipcMain.on('audio-status-update', (event, args) => {
    if (settingsWindow) {
      settingsWindow.webContents.send('audio-status-update', args);
    }
  });

  // ----------------------------------------------------
  // Project Explorer Folder & File management APIs
  // ----------------------------------------------------
  ipcMain.handle('read-project-directory', async (event, folderPath) => {
    try {
      if (!fs.existsSync(folderPath)) {
        return { success: false, error: 'Directory does not exist' };
      }
      const files = fs.readdirSync(folderPath);
      const fileInfos = files.map(file => {
        const filePath = path.join(folderPath, file);
        let stat;
        try {
          stat = fs.statSync(filePath);
        } catch (e) {
          return null; // Skip locked or special system files
        }
        return {
          name: file,
          isDirectory: stat.isDirectory(),
          size: stat.size,
          mtime: stat.mtime.getTime()
        };
      }).filter(f => f !== null);

      return { success: true, files: fileInfos };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  ipcMain.handle('delete-path', async (event, targetPath) => {
    try {
      if (!fs.existsSync(targetPath)) {
        return { success: false, error: 'Path does not exist' };
      }
      const stat = fs.statSync(targetPath);
      if (stat.isDirectory()) {
        fs.rmSync(targetPath, { recursive: true, force: true });
      } else {
        fs.unlinkSync(targetPath);
      }
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  ipcMain.handle('create-project-folder', async (event, targetPath) => {
    try {
      fs.mkdirSync(targetPath, { recursive: true });
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  ipcMain.handle('delete-project-folder', async (event, folderPath) => {
    try {
      if (fs.existsSync(folderPath)) {
        fs.rmSync(folderPath, { recursive: true, force: true });
      }
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  ipcMain.handle('open-project-folder', async (event, folderPath) => {
    try {
      if (!fs.existsSync(folderPath)) {
        return { success: false, error: 'Folder does not exist' };
      }
      await shell.openPath(folderPath);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  ipcMain.handle('zip-project-folder', async (event, folderPath) => {
    try {
      if (!fs.existsSync(folderPath)) {
        return { success: false, error: 'Folder does not exist on disk' };
      }
      const zipPath = `${folderPath}.zip`;
      
      // PowerShell Compress-Archive command excluding node_modules is fast and locks-safe
      const powershellCmd = `powershell -Command "Get-ChildItem -Path '${folderPath}' -Exclude 'node_modules' | Compress-Archive -DestinationPath '${zipPath}' -Force"`;
      
      return new Promise((resolve) => {
        exec(powershellCmd, (err) => {
          if (err) {
            resolve({ success: false, error: err.message });
          } else {
            resolve({ success: true, zipPath });
          }
        });
      });
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  ipcMain.handle('take-screenshot', async (event, filename) => {
    try {
      const win = settingsWindow;
      const image = await win.webContents.capturePage();
      const savePath = path.join('C:\\Users\\absal\\.gemini\\antigravity-ide\\brain\\bc30c9b5-4ce7-4d01-aa44-1221a1a28bf0', filename);
      fs.writeFileSync(savePath, image.toPNG());
      return { success: true, savePath };
    } catch (err) {
      console.error('Failed to take screenshot:', err);
      return { success: false, error: err.message };
    }
  });

  // Listener to open TrackXpense Ledger
  ipcMain.on('open-ledger', () => {
    openLedgerWindow();
  });
}

// Electron lifecycle hooks
app.whenReady().then(() => {
  // Handle trackxpense:// protocol requests
  protocol.handle('trackxpense', (request) => {
    try {
      const url = new URL(request.url);
      let pathname = url.pathname;
      pathname = decodeURIComponent(pathname);
      
      if (pathname === '/' || pathname === '') {
        pathname = '/index.html';
      }
      
      const filePath = path.join('c:\\Projects\\trackxpense\\dist', pathname);
      return net.fetch(pathToFileURL(filePath).toString());
    } catch (err) {
      console.error('Protocol handler error:', err);
      return new Response('Not Found', { status: 404 });
    }
  });

  Menu.setApplicationMenu(null); // Remove default menus globally
  setupIpc();
  createCommandBarWindow();
  createSettingsWindow();

  const config = loadConfig();
  registerHotkey(config.hotkey);

  const iconPath = path.join(__dirname, 'icon.png');
  const { nativeImage } = require('electron');
  const trayIcon = fs.existsSync(iconPath) ? iconPath : nativeImage.createEmpty();

  tray = new Tray(trayIcon);
  const contextMenu = Menu.buildFromTemplate([
    { label: 'Open Search (Ctrl+Shift+Space)', click: () => { toggleCommandBar(); } },
    { label: 'Open Settings Dashboard', click: () => { if (settingsWindow) settingsWindow.show(); } },
    { type: 'separator' },
    { label: 'Quit aegis Engine', click: () => {
      app.isQuiting = true;
      app.quit();
    } }
  ]);
  tray.setToolTip('aegis');
  tray.setContextMenu(contextMenu);

  tray.on('double-click', () => {
    if (settingsWindow) {
      settingsWindow.show();
      settingsWindow.focus();
    }
  });
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
});

// Avoid quitting on all windows closed to persist running state in tray
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    // Keep running background shortcuts
  }
});
const { ipcRenderer } = require('electron');

let config = null;
let filteredItems = [];
let selectedIndex = 0;
let focusModeActive = false;

const searchInput = document.getElementById('search-input');
const resultsList = document.getElementById('results-list');
const blurBg = document.getElementById('blur-bg');
const statusBadge = document.getElementById('status-badge');
const tipText = document.getElementById('tip-text');
const toast = document.getElementById('toast-notification');

// Define commands list
const commands = [
  { type: 'command', title: '/settings', desc: 'Open aegis Dashboard', cmd: 'settings' },
  { type: 'command', title: '/focus', desc: 'Toggle Deep-Focus Mode (kills distractions)', cmd: 'focus' },
  { type: 'command', title: '/timer [mins]', desc: 'Start a focus countdown timer (default: 25)', cmd: 'timer' },
  { type: 'command', title: '/reminder [text] [mins]', desc: 'Schedule a custom reminder', cmd: 'reminder' },
  { type: 'command', title: '/ledger', desc: 'Open TrackXpense Finance Ledger', cmd: 'ledger' },
  { type: 'command', title: '/exit', desc: 'Exit background application fully', cmd: 'exit' }
];

// Initialize configuration
async function init() {
  config = await ipcRenderer.invoke('get-config');
  renderItems();
  
  // Set up search listening
  searchInput.addEventListener('input', () => {
    selectedIndex = 0;
    renderItems();
  });
}

// Receive screen capture data
ipcRenderer.on('bg-captured', (event, imgData) => {
  blurBg.style.backgroundImage = `url(${imgData})`;
});

// Force focus on input when window shows
ipcRenderer.on('focus-input', () => {
  searchInput.value = '';
  selectedIndex = 0;
  renderItems();
  setTimeout(() => searchInput.focus(), 50);
});

// Sync focus status
ipcRenderer.on('focus-status', (event, active) => {
  focusModeActive = active;
  if (active) {
    statusBadge.classList.remove('hidden');
  } else {
    statusBadge.classList.add('hidden');
  }
});

// Toast notification helper
let toastTimeout = null;
function showToast(text) {
  if (toastTimeout) clearTimeout(toastTimeout);
  toast.textContent = text;
  toast.classList.add('visible');
  toastTimeout = setTimeout(() => {
    toast.classList.remove('visible');
  }, 3000);
}

// Render filtered command bar items
function renderItems() {
  resultsList.innerHTML = '';
  const query = searchInput.value.trim().toLowerCase();
  
  if (query.startsWith('/')) {
    // Show only commands matching query
    filteredItems = commands.filter(item => item.title.toLowerCase().startsWith(query));
  } else {
    // Show matching projects
    filteredItems = (config?.projects || []).filter(proj => 
      proj.name.toLowerCase().includes(query) ||
      (proj.description && proj.description.toLowerCase().includes(query)) ||
      proj.software.toLowerCase().includes(query)
    ).map(proj => ({
      type: 'project',
      name: proj.name,
      software: proj.software,
      description: proj.description || '',
      path: proj.path
    }));
  }
  
  if (filteredItems.length === 0) {
    resultsList.innerHTML = `
      <div style="color: rgba(255, 255, 255, 0.4); text-align: center; padding: 24px; font-size: 13px;">
        No matches found
      </div>
    `;
    return;
  }
  
  filteredItems.forEach((item, idx) => {
    const div = document.createElement('div');
    div.classList.add('result-item');
    if (idx === selectedIndex) {
      div.classList.add('selected');
    }
    
    if (item.type === 'command') {
      div.innerHTML = `
        <div class="item-icon">/</div>
        <div class="item-details">
          <span class="item-title">${item.title}</span>
          <span class="item-desc">${item.desc}</span>
        </div>
        <span class="item-meta">Command</span>
      `;
    } else {
      // It's a project
      const sw = config.softwares[item.software] || {};
      const swColor = sw.icon_color || '#0078D4';
      
      div.innerHTML = `
        <div class="item-icon" style="border-color: ${swColor}40; color: ${swColor};">${item.software[0]}</div>
        <div class="item-details">
          <span class="item-title">${item.name}</span>
          <span class="item-desc">${item.description || item.path}</span>
        </div>
        <span class="item-meta" data-software="${item.software}" style="border-color: ${swColor}40; color: ${swColor};">${item.software}</span>
      `;
    }
    
    div.addEventListener('click', () => {
      selectedIndex = idx;
      updateSelection();
      triggerSelected();
    });
    
    resultsList.appendChild(div);
  });
}

function updateSelection() {
  const items = resultsList.querySelectorAll('.result-item');
  items.forEach((item, idx) => {
    if (idx === selectedIndex) {
      item.classList.add('selected');
      item.scrollIntoView({ block: 'nearest' });
    } else {
      item.classList.remove('selected');
    }
  });
}

async function triggerSelected() {
  if (filteredItems[selectedIndex]) {
    const selected = filteredItems[selectedIndex];
    if (selected.type === 'command') {
      executeCommand(selected.cmd);
    } else {
      const res = await ipcRenderer.invoke('launch-project', selected.name);
      if (res.success) {
        ipcRenderer.send('hide-commandbar');
      } else {
        showToast(`Launch failed: ${res.error}`);
      }
    }
  }
}

// Keyboard Navigation & Escape hide
window.addEventListener('keydown', async (e) => {
  if (e.key === 'Escape') {
    ipcRenderer.send('hide-commandbar');
  } else if (e.key === 'ArrowDown') {
    e.preventDefault();
    if (filteredItems.length > 0) {
      selectedIndex = (selectedIndex + 1) % filteredItems.length;
      updateSelection();
    }
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    if (filteredItems.length > 0) {
      selectedIndex = (selectedIndex - 1 + filteredItems.length) % filteredItems.length;
      updateSelection();
    }
  } else if (e.key === 'Enter') {
    e.preventDefault();
    triggerSelected();
  }
});

// Execute selected slash command
async function executeCommand(cmdStr) {
  const query = searchInput.value.trim();
  
  if (cmdStr === 'settings') {
    ipcRenderer.send('open-settings');
    ipcRenderer.send('hide-commandbar');
  } else if (cmdStr === 'focus') {
    const active = await ipcRenderer.invoke('toggle-focus');
    showToast(active ? 'Focus Mode Enabled!' : 'Focus Mode Disabled!');
    ipcRenderer.send('hide-commandbar');
  } else if (cmdStr === 'timer') {
    const parts = query.split(' ');
    const mins = parts[1] ? parseInt(parts[1]) : 25;
    if (isNaN(mins) || mins <= 0) {
      showToast('Invalid duration! Enter positive minutes.');
      return;
    }
    await ipcRenderer.invoke('add-reminder', 'timer', 'Focus Session', mins);
    showToast(`Timer scheduled for ${mins}m`);
    ipcRenderer.send('hide-commandbar');
  } else if (cmdStr === 'reminder') {
    const parts = query.split(' ');
    let mins = 10;
    let text = 'Quick Reminder';
    
    if (parts.length > 1) {
      const lastPart = parts[parts.length - 1];
      const parsedMins = parseInt(lastPart);
      if (!isNaN(parsedMins) && parsedMins > 0) {
        mins = parsedMins;
        text = parts.slice(1, -1).join(' ');
      } else {
        text = parts.slice(1).join(' ');
      }
    }
    await ipcRenderer.invoke('add-reminder', 'reminder', text, mins);
    showToast(`Reminder scheduled for ${mins}m`);
    ipcRenderer.send('hide-commandbar');
  } else if (cmdStr === 'ledger') {
    ipcRenderer.send('open-ledger');
    ipcRenderer.send('hide-commandbar');
  } else if (cmdStr === 'exit') {
    ipcRenderer.send('exit-app');
  }
}

// ----------------------------------------------------
// Web Audio API Procedural Synthesizer Engine
// ----------------------------------------------------
let audioCtx = null;
let rainSource = null;
let rainGain = null;
let lofiInterval = null;
let lofiVolume = 0.2;
let chordIndex = 0;

const chords = [
  [130.81, 164.81, 196.00, 246.94], // C3, E3, G3, B3 (Cmaj7)
  [146.83, 174.61, 220.00, 261.63], // D3, F3, A3, C4 (Dm7)
  [110.00, 138.61, 164.81, 207.65], // A2, C#3, E3, G#3 (Amaj7)
  [116.54, 138.61, 174.61, 233.08]  // Bb2, Db3, F3, Bb3 (Bbm7)
];

function initAudioContext() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
}

function playRain(volume) {
  initAudioContext();
  if (rainSource) return;

  const bufferSize = 2 * audioCtx.sampleRate;
  const noiseBuffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
  const output = noiseBuffer.getChannelData(0);

  let b0, b1, b2, b3, b4, b5, b6;
  b0 = b1 = b2 = b3 = b4 = b5 = b6 = 0.0;

  for (let i = 0; i < bufferSize; i++) {
    const white = Math.random() * 2 - 1;
    b0 = 0.99886 * b0 + white * 0.0555179;
    b1 = 0.99332 * b1 + white * 0.0750759;
    b2 = 0.96900 * b2 + white * 0.1538520;
    b3 = 0.86650 * b3 + white * 0.3104856;
    b4 = 0.55000 * b4 + white * 0.5329522;
    b5 = -0.7616 * b5 - white * 0.0168980;
    output[i] = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
    output[i] *= 0.11; // Clip avoidance
    b6 = white * 0.115926;
  }

  rainSource = audioCtx.createBufferSource();
  rainSource.buffer = noiseBuffer;
  rainSource.loop = true;

  const filter = audioCtx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(650, audioCtx.currentTime);

  rainGain = audioCtx.createGain();
  rainGain.gain.setValueAtTime(volume, audioCtx.currentTime);

  rainSource.connect(filter);
  filter.connect(rainGain);
  rainGain.connect(audioCtx.destination);

  rainSource.start();
  ipcRenderer.send('audio-status-update', { type: 'rain', playing: true });
}

function stopRain() {
  if (rainSource) {
    try {
      rainSource.stop();
    } catch(e) {}
    rainSource = null;
  }
  ipcRenderer.send('audio-status-update', { type: 'rain', playing: false });
}

function playLofi(volume) {
  lofiVolume = volume;
  initAudioContext();
  if (lofiInterval) return;

  const filter = audioCtx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(320, audioCtx.currentTime);
  filter.connect(audioCtx.destination);

  function playChord() {
    if (!lofiInterval) return; // safety stop
    const now = audioCtx.currentTime;
    const freqs = chords[chordIndex];
    chordIndex = (chordIndex + 1) % chords.length;

    freqs.forEach(f => {
      const osc = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, now);

      gainNode.gain.setValueAtTime(0, now);
      gainNode.gain.linearRampToValueAtTime(lofiVolume * 0.18, now + 0.5);
      gainNode.gain.exponentialRampToValueAtTime(0.001, now + 3.8);

      osc.connect(gainNode);
      gainNode.connect(filter);

      osc.start(now);
      osc.stop(now + 4);
    });
  }

  lofiInterval = setInterval(playChord, 4000);
  playChord();
  ipcRenderer.send('audio-status-update', { type: 'lofi', playing: true });
}

function stopLofi() {
  if (lofiInterval) {
    clearInterval(lofiInterval);
    lofiInterval = null;
  }
  ipcRenderer.send('audio-status-update', { type: 'lofi', playing: false });
}

// Listen for Audio Controls from Settings
ipcRenderer.on('audio-control', (event, { type, action, volume }) => {
  if (type === 'rain') {
    if (action === 'play') {
      playRain(volume !== undefined ? volume : 0.5);
    } else if (action === 'stop') {
      stopRain();
    } else if (action === 'volume') {
      if (rainGain) {
        rainGain.gain.setValueAtTime(volume, audioCtx.currentTime);
      }
    }
  } else if (type === 'lofi') {
    if (action === 'play') {
      playLofi(volume !== undefined ? volume : 0.2);
    } else if (action === 'stop') {
      stopLofi();
    } else if (action === 'volume') {
      lofiVolume = volume;
    }
  }
});

// ----------------------------------------------------
// Active Countdown Timer Ticker in footer
// ----------------------------------------------------
setInterval(async () => {
  const currentConfig = await ipcRenderer.invoke('get-config');
  const activeReminders = (currentConfig.reminders || []).filter(r => r.status === 'active');
  
  if (activeReminders.length > 0) {
    // Show countdown for closest expiring reminder
    activeReminders.sort((a, b) => new Date(a.expiresAt) - new Date(b.expiresAt));
    const next = activeReminders[0];
    
    const remainingMs = new Date(next.expiresAt) - Date.now();
    if (remainingMs > 0) {
      const totalSecs = Math.floor(remainingMs / 1000);
      const m = Math.floor(totalSecs / 60);
      const s = totalSecs % 60;
      const timeStr = `${m}:${s.toString().padStart(2, '0')}`;
      const typeLabel = next.type === 'timer' ? 'Timer' : 'Reminder';
      tipText.innerHTML = `<span style="font-weight: 600; color: #a78bfa; text-transform: uppercase; margin-right: 4px;">[${typeLabel}]</span>${next.text}: <span style="color: #c084fc; font-weight: bold;">${timeStr} left</span>`;
      return;
    }
  }
  
  // Default footer tip
  tipText.innerHTML = 'Type <kbd>/</kbd> for system commands';
}, 1000);

// Startup App
init();
const { ipcRenderer } = require('electron');

let config = null;
let currentEditingProjectIndex = -1;

// Inline SVG Icon Definitions for Minimalistic UI
const pencilSvg = `<svg viewBox="0 0 24 24"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>`;
const trashSvg = `<svg viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>`;
const folderSvg = `<svg viewBox="0 0 24 24" width="12" height="12"><path d="M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/></svg>`;
const infoSvg = `<svg viewBox="0 0 24 24" width="12" height="12"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>`;
const fileIconSvg = `<svg viewBox="0 0 24 24" width="16" height="16"><path d="M6 2c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6H6zm7 7V3.5L18.5 9H13z"/></svg>`;

// DOM Elements: Header View Toggles
const btnToggleReminders = document.getElementById('btn-toggle-reminders');
const btnToggleSettings = document.getElementById('btn-toggle-settings');
const btnOpenLedger = document.getElementById('btn-open-ledger');
const viewPanes = document.querySelectorAll('.view-pane');

// DOM Elements: Sidebar Tabs (Internal settings)
const navItems = document.querySelectorAll('.nav-item');
const tabContents = document.querySelectorAll('.tab-content');
const btnSaveAll = document.getElementById('btn-save-all');
const btnQuitApp = document.getElementById('btn-quit-app');

// Projects Elements
const projectsList = document.getElementById('projects-list');
const btnAddProject = document.getElementById('btn-add-project');
const projectModal = document.getElementById('project-modal');
const modalProjectTitle = document.getElementById('modal-project-title');
const modalProjName = document.getElementById('modal-proj-name');
const modalProjSoftware = document.getElementById('modal-proj-software');
const modalProjPath = document.getElementById('modal-proj-path');
const modalProjDesc = document.getElementById('modal-proj-desc');
const modalProjCancel = document.getElementById('modal-proj-cancel');
const modalProjSave = document.getElementById('modal-proj-save');

// Softwares & Distractions
const softwaresList = document.getElementById('softwares-list');
const distractionsList = document.getElementById('distractions-list');
const btnAddDistraction = document.getElementById('btn-add-distraction');

// Add Software modal elements
const btnAddSoftware = document.getElementById('btn-add-software');
const softwareModal = document.getElementById('software-modal');
const modalSoftName = document.getElementById('modal-soft-name');
const modalSoftPath = document.getElementById('modal-soft-path');
const modalSoftColor = document.getElementById('modal-soft-color');
const modalSoftColorHex = document.getElementById('modal-soft-color-hex');
const modalSoftDir = document.getElementById('modal-soft-dir');
const modalSoftCancel = document.getElementById('modal-soft-cancel');
const modalSoftSave = document.getElementById('modal-soft-save');

// Delete project confirm modal elements
const deleteConfirmModal = document.getElementById('delete-confirm-modal');
const btnDeleteCockpitOnly = document.getElementById('btn-delete-cockpit-only');
const btnDeleteFull = document.getElementById('btn-delete-full');
const btnDeleteCancel = document.getElementById('btn-delete-cancel');

// Project Explorer elements
const viewProjectExplorer = document.getElementById('view-project-explorer');
const explorerProjectName = document.getElementById('explorer-project-name');
const explorerProjectPath = document.getElementById('explorer-project-path');
const explorerFilesList = document.getElementById('explorer-files-list');
const btnExplorerBack = document.getElementById('btn-explorer-back');
const btnExplorerOpen = document.getElementById('btn-explorer-open');
const btnExplorerZip = document.getElementById('btn-explorer-zip');

let projectToDeleteIndex = -1;
let currentExplorerProject = null;

// System Configurations
const hotkeyInput = document.getElementById('hotkey-input');
const btnRecordHotkey = document.getElementById('btn-record-hotkey');
const defaultDirInput = document.getElementById('default-dir-input');

// Project Modal Elements
const btnModalCreateFolder = document.getElementById('btn-modal-create-folder');

// Reminders Elements
const activeRemindersList = document.getElementById('active-reminders-list');
const pastRemindersList = document.getElementById('past-reminders-list');
const reminderTypeSelect = document.getElementById('reminder-type-select');
const reminderTextInput = document.getElementById('reminder-text-input');
const reminderMinsInput = document.getElementById('reminder-mins-input');
const btnSaveReminder = document.getElementById('btn-save-reminder');
const btnClearHistory = document.getElementById('btn-clear-history');
const systemProjectModal = document.getElementById('system-project-modal');
const btnSystemProjectOk = document.getElementById('btn-system-project-ok');

// Titlebar Window Controls
const btnMin = document.getElementById('titlebar-min');
const btnMax = document.getElementById('titlebar-max');
const btnClose = document.getElementById('titlebar-close');

btnMin.addEventListener('click', () => {
  ipcRenderer.send('window-minimize');
});

btnMax.addEventListener('click', () => {
  ipcRenderer.send('window-maximize');
});

btnClose.addEventListener('click', () => {
  ipcRenderer.send('window-close');
});

ipcRenderer.on('window-maximized-status', (event, isMaximized) => {
  if (isMaximized) {
    btnMax.innerHTML = `
      <svg viewBox="0 0 10 10" width="10" height="10"><path d="M0 2v8h8V2H0zm7 7H1V3h6v6zm1-8H2v1h5v5h1V1z" fill="currentColor"/></svg>
    `;
    btnMax.title = "Restore Down";
  } else {
    btnMax.innerHTML = `
      <svg viewBox="0 0 10 10" width="10" height="10"><path d="M0 0v10h10V0H0zm9 9H1V1h8v8z" fill="currentColor"/></svg>
    `;
    btnMax.title = "Maximize";
  }
});

// Initialize settings dashboard
async function init() {
  config = await ipcRenderer.invoke('get-config');
  
  // Render views
  renderProjects();
  renderSoftwares();
  renderDistractions();
  
  // Set system configs
  hotkeyInput.value = config.hotkey || 'ctrl+shift+space';
  defaultDirInput.value = config.default_projects_dir || '';
  
  // Get initial Focus Mode status and update status bar
  const focusActive = await ipcRenderer.invoke('get-focus-status');
  updateFocusStatusBar(focusActive);
  
  // Tab Navigation Click Event inside settings tab
  navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const tabName = item.getAttribute('data-tab');
      
      navItems.forEach(nav => nav.classList.remove('active'));
      tabContents.forEach(content => content.classList.remove('active'));
      
      item.classList.add('active');
      document.getElementById(`tab-content-${tabName}`).classList.add('active');
    });
  });
}

// ----------------------------------------------------
// View Switcher System
// ----------------------------------------------------
function switchView(viewName) {
  viewPanes.forEach(pane => pane.classList.remove('active'));
  btnToggleSettings.classList.remove('active');
  btnToggleReminders.classList.remove('active');

  // Plus button should only be visible when looking at the projects grid view
  if (viewName === 'projects') {
    btnAddProject.style.display = 'flex';
  } else {
    btnAddProject.style.display = 'none';
  }

  if (viewName === 'settings') {
    btnToggleSettings.classList.add('active');
    document.getElementById('view-settings').classList.add('active');
  } else if (viewName === 'reminders') {
    btnToggleReminders.classList.add('active');
    document.getElementById('view-reminders').classList.add('active');
    renderReminders();
  } else if (viewName === 'explorer') {
    document.getElementById('view-project-explorer').classList.add('active');
  } else {
    document.getElementById('view-projects').classList.add('active');
  }
}

btnToggleSettings.addEventListener('click', () => {
  const isActive = btnToggleSettings.classList.contains('active');
  switchView(isActive ? 'projects' : 'settings');
});

btnToggleReminders.addEventListener('click', () => {
  const isActive = btnToggleReminders.classList.contains('active');
  switchView(isActive ? 'projects' : 'reminders');
});

btnOpenLedger.addEventListener('click', () => {
  ipcRenderer.send('open-ledger');
});

// ----------------------------------------------------
// 1. Projects Management (Icon-only actions)
// ----------------------------------------------------
function renderProjects() {
  projectsList.innerHTML = '';
  const projects = config.projects || [];
  
  if (projects.length === 0) {
    projectsList.innerHTML = `
      <div class="settings-card card-info" style="grid-column: span 2;">
        <div class="card-details">
          <span class="card-title">No projects configured</span>
          <span class="card-desc">Click the plus icon (+) above to register your first workspace project.</span>
        </div>
      </div>
    `;
    return;
  }
  
  projects.forEach((proj, idx) => {
    const card = document.createElement('div');
    card.classList.add('settings-card');
    if (proj.isSystem) {
      card.classList.add('system-project');
    }
    
    const softwareInfo = config.softwares[proj.software] || { icon_color: '#8b5cf6' };
    const swColor = softwareInfo.icon_color || '#8b5cf6';
    
    card.setAttribute('style', `
      --proj-color: ${swColor};
      --proj-color-bg: ${swColor}0d;
      --proj-color-glow: ${swColor}1f;
      --proj-color-border: ${swColor}33;
      --proj-color-border-bottom: ${swColor}66;
      --proj-color-hover-border: ${swColor}4d;
      --proj-color-hover-border-bottom: ${swColor}80;
    `);
    
    const pathHtml = proj.path ? `
      <span class="card-desc">
        ${folderSvg}
        <code>${proj.path}</code>
      </span>
    ` : '';
    
    const descHtml = proj.description ? `
      <span class="card-desc-sub">
        ${infoSvg}
        ${proj.description}
      </span>
    ` : '';
    
    card.innerHTML = `
      <div class="card-details">
        <div class="card-title-row">
          <span class="card-title">${proj.name}</span>
          <span class="card-software-badge" data-software="${proj.software}" style="--sw-color: ${swColor}; --sw-color-bg: ${swColor}1a; --sw-color-border: ${swColor}33;">
            ${proj.software}
          </span>
        </div>
        ${pathHtml}
        ${descHtml}
      </div>
      <div class="card-actions">
        <button class="icon-action-btn btn-edit-proj" data-index="${idx}" title="Edit Project">
          ${pencilSvg}
        </button>
        <button class="icon-action-btn btn-delete-proj" data-index="${idx}" title="Delete Project">
          ${trashSvg}
        </button>
      </div>
    `;
    
    // Clicking the card anywhere except the action buttons should open the File Explorer
    card.addEventListener('click', (e) => {
      if (e.target.closest('.card-actions')) {
        return;
      }
      openProjectExplorer(proj);
    });
    
    projectsList.appendChild(card);
  });
  
  // Bind Action Events
  document.querySelectorAll('.btn-edit-proj').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const idx = parseInt(btn.getAttribute('data-index'));
      if (config.projects[idx] && config.projects[idx].isSystem) {
        systemProjectModal.classList.remove('hidden');
        return;
      }
      openProjectModal(idx);
    });
  });
  
  document.querySelectorAll('.btn-delete-proj').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const idx = parseInt(btn.getAttribute('data-index'));
      if (config.projects[idx] && config.projects[idx].isSystem) {
        systemProjectModal.classList.remove('hidden');
        return;
      }
      openDeleteConfirmation(idx);
    });
  });
}

// Open Project Files Explorer view
function openProjectExplorer(proj) {
  currentExplorerProject = proj;
  explorerProjectName.textContent = proj.name;
  explorerProjectPath.textContent = proj.path || 'No local directory path specified';
  switchView('explorer');
  renderExplorerFiles(proj.path);
}

// Read and render files inside project directory
async function renderExplorerFiles(folderPath) {
  explorerFilesList.innerHTML = `
    <tr>
      <td colspan="4" style="text-align: center; color: var(--text-secondary); padding: 24px;">
        Loading project files...
      </td>
    </tr>
  `;

  if (!folderPath) {
    explorerFilesList.innerHTML = `
      <tr>
        <td colspan="4" style="text-align: center; color: var(--text-secondary); padding: 24px;">
          No directory path configured for this project.
        </td>
      </tr>
    `;
    return;
  }

  const res = await ipcRenderer.invoke('read-project-directory', folderPath);
  if (!res.success) {
    explorerFilesList.innerHTML = `
      <tr>
        <td colspan="4" style="text-align: center; color: #f87171; padding: 24px;">
          Error reading directory: ${res.error}
        </td>
      </tr>
    `;
    return;
  }

  const files = res.files || [];
  if (files.length === 0) {
    explorerFilesList.innerHTML = `
      <tr>
        <td colspan="4" style="text-align: center; color: var(--text-secondary); padding: 24px;">
          This folder is empty.
        </td>
      </tr>
    `;
    return;
  }

  // Sort files: directories first, then alphabetically
  files.sort((a, b) => {
    if (a.isDirectory && !b.isDirectory) return -1;
    if (!a.isDirectory && b.isDirectory) return 1;
    return a.name.localeCompare(b.name);
  });

  explorerFilesList.innerHTML = '';
  files.forEach(file => {
    const row = document.createElement('tr');
    
    // File size formatting
    let sizeStr = '--';
    if (!file.isDirectory) {
      const sizeBytes = file.size || 0;
      if (sizeBytes < 1024) sizeStr = `${sizeBytes} B`;
      else if (sizeBytes < 1024 * 1024) sizeStr = `${(sizeBytes / 1024).toFixed(1)} KB`;
      else sizeStr = `${(sizeBytes / (1024 * 1024)).toFixed(1)} MB`;
    }

    // Last modified formatting
    const mtimeStr = file.mtime ? new Date(file.mtime).toLocaleString() : '--';

    // Icon (Folder vs File)
    const icon = file.isDirectory ? folderSvg : fileIconSvg;
    const nameClass = file.isDirectory ? 'file-item-name directory-type' : 'file-item-name';

    row.innerHTML = `
      <td>
        <div class="${nameClass}">
          ${icon}
          <span>${file.name}</span>
        </div>
      </td>
      <td style="color: var(--text-secondary); font-family: Consolas, monospace;">${sizeStr}</td>
      <td style="color: var(--text-secondary);">${mtimeStr}</td>
      <td style="text-align: right; padding-right: 24px;">
        <div class="file-actions-cell">
          <button class="icon-action-btn btn-delete-file" data-name="${file.name}" title="Delete File/Folder">
            ${trashSvg}
          </button>
        </div>
      </td>
    `;

    explorerFilesList.appendChild(row);
  });

  // Bind individual file delete actions
  document.querySelectorAll('.btn-delete-file').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const fileName = btn.getAttribute('data-name');
      const targetPath = `${folderPath}\\${fileName}`;
      if (confirm(`Are you sure you want to permanently delete "${fileName}" from disk?`)) {
        const res = await ipcRenderer.invoke('delete-path', targetPath);
        if (res.success) {
          renderExplorerFiles(folderPath);
        } else {
          alert(`Failed to delete:\n${res.error}`);
        }
      }
    });
  });
}

// Open custom warnings modal for deleting project
function openDeleteConfirmation(idx) {
  projectToDeleteIndex = idx;
  const proj = config.projects[idx];
  document.getElementById('delete-modal-warning-text').textContent = `Are you sure you want to delete the project "${proj.name}"? Please choose how you would like to delete it.`;
  deleteConfirmModal.classList.remove('hidden');
}

// Hide delete confirmation modal
function closeDeleteConfirmation() {
  deleteConfirmModal.classList.add('hidden');
  projectToDeleteIndex = -1;
}

function populateSoftwareDropdown() {
  modalProjSoftware.innerHTML = '';
  const softwares = Object.keys(config.softwares || {});
  softwares.forEach(sw => {
    const opt = document.createElement('option');
    opt.value = sw;
    opt.textContent = sw;
    modalProjSoftware.appendChild(opt);
  });
}

function openProjectModal(index = -1) {
  currentEditingProjectIndex = index;
  populateSoftwareDropdown();
  
  if (index >= 0) {
    const proj = config.projects[index];
    modalProjectTitle.textContent = 'Edit Workspace Project';
    modalProjName.value = proj.name;
    modalProjSoftware.value = proj.software;
    modalProjPath.value = proj.path;
    modalProjDesc.value = proj.description || '';
  } else {
    modalProjectTitle.textContent = 'Add Workspace Project';
    modalProjName.value = '';
    modalProjSoftware.selectedIndex = 0;
    modalProjPath.value = '';
    modalProjDesc.value = '';
  }
  
  projectModal.classList.remove('hidden');
}

modalProjCancel.addEventListener('click', () => {
  projectModal.classList.add('hidden');
});

modalProjSave.addEventListener('click', () => {
  const name = modalProjName.value.trim();
  const software = modalProjSoftware.value;
  const path = modalProjPath.value.trim();
  const description = modalProjDesc.value.trim();
  
  if (!name) {
    alert('Project Name is required.');
    return;
  }
  
  const projectData = { name, software, path, description };
  
  if (currentEditingProjectIndex >= 0) {
    config.projects[currentEditingProjectIndex] = projectData;
  } else {
    config.projects.push(projectData);
  }
  
  projectModal.classList.add('hidden');
  renderProjects();
});

btnAddProject.addEventListener('click', () => {
  openProjectModal(-1);
});

btnModalCreateFolder.addEventListener('click', async (e) => {
  e.preventDefault();
  const projName = modalProjName.value.trim();
  if (!projName) {
    alert('Please enter a Project Name first.');
    return;
  }
  
  // Try software-specific default projects directory first
  const selectedSw = modalProjSoftware.value;
  const swConfig = config.softwares[selectedSw] || {};
  let baseDir = (swConfig.default_dir || '').trim();
  
  // Fall back to global default projects directory
  if (!baseDir) {
    baseDir = defaultDirInput.value.trim();
  }
  
  if (!baseDir) {
    alert('Please configure a Default Projects Directory for this Software, or a global fallback in System Settings.');
    return;
  }
  
  // Safe folder name (remove illegal filesystem chars)
  const safeName = projName.replace(/[^a-zA-Z0-9-_ ]/g, '').trim();
  const separator = baseDir.endsWith('\\') || baseDir.endsWith('/') ? '' : '\\';
  const targetPath = `${baseDir}${separator}${safeName}`;
  
  modalProjPath.value = targetPath;
  
  const res = await ipcRenderer.invoke('create-project-folder', targetPath);
  if (res.success) {
    alert(`Folder created successfully at:\n${targetPath}`);
  } else {
    alert(`Failed to create folder:\n${res.error}`);
  }
});

// ----------------------------------------------------
// 2. Softwares Configuration
// ----------------------------------------------------
function renderSoftwares() {
  softwaresList.innerHTML = '';
  const softwares = config.softwares || {};
  
  Object.keys(softwares).forEach(name => {
    const sw = softwares[name];
    const card = document.createElement('div');
    card.classList.add('settings-card');
    
    card.innerHTML = `
      <div class="card-details">
        <span class="card-title">${name}</span>
        <span class="card-desc">Configure executable paths and projects directory</span>
      </div>
      <div class="sw-grid-actions">
        <div class="sw-form-row">
          <label>Exec Path:</label>
          <input type="text" class="text-input sw-path-input" data-software="${name}" value="${sw.exec_path}" placeholder="e.g. C:\\Program Files\\...\\app.exe">
          <input type="color" class="color-picker-input sw-color-input" data-software="${name}" value="${sw.icon_color || '#8b5cf6'}">
        </div>
        <div class="sw-form-row">
          <label>Projects Dir:</label>
          <input type="text" class="text-input sw-dir-input" data-software="${name}" value="${sw.default_dir || ''}" placeholder="e.g. C:\\Users\\Default\\Documents\\Projects">
        </div>
      </div>
    `;
    
    softwaresList.appendChild(card);
  });
  
  // Listen for changes in Software cards
  softwaresList.addEventListener('change', (e) => {
    const target = e.target;
    const softwareName = target.getAttribute('data-software');
    if (!softwareName) return;
    
    if (target.classList.contains('sw-path-input')) {
      config.softwares[softwareName].exec_path = target.value.trim();
    } else if (target.classList.contains('sw-dir-input')) {
      config.softwares[softwareName].default_dir = target.value.trim();
    } else if (target.classList.contains('sw-color-input')) {
      config.softwares[softwareName].icon_color = target.value;
    }
  });
}

// ----------------------------------------------------
// 3. Focus / Distractions Blocklist (Icon-only actions)
// ----------------------------------------------------
function renderDistractions() {
  distractionsList.innerHTML = '';
  const distractions = config.distractions || [];
  
  if (distractions.length === 0) {
    distractionsList.innerHTML = `
      <div class="settings-card card-info">
        <div class="card-details">
          <span class="card-title">Blocklist is empty</span>
          <span class="card-desc">Click the plus icon (+) above to define distractions.</span>
        </div>
      </div>
    `;
    return;
  }
  
  distractions.forEach((dist, idx) => {
    const card = document.createElement('div');
    card.classList.add('settings-card');
    
    card.innerHTML = `
      <div class="card-details">
        <span class="distraction-title">${dist}</span>
      </div>
      <div class="card-actions">
        <button class="icon-action-btn btn-delete-dist" data-index="${idx}" title="Remove App">
          ${trashSvg}
        </button>
      </div>
    `;
    
    distractionsList.appendChild(card);
  });
  
  // Bind actions
  document.querySelectorAll('.btn-delete-dist').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = parseInt(btn.getAttribute('data-index'));
      config.distractions.splice(idx, 1);
      renderDistractions();
    });
  });
}

btnAddDistraction.addEventListener('click', () => {
  const appName = prompt('Enter distraction process name (e.g., steam.exe, discord.exe):');
  if (appName && appName.trim()) {
    const cleanName = appName.trim().toLowerCase();
    if (!config.distractions.includes(cleanName)) {
      config.distractions.push(cleanName);
      renderDistractions();
    }
  }
});

// ----------------------------------------------------
// 4. Hotkey System Recording
// ----------------------------------------------------
let recordingHotkey = false;

btnRecordHotkey.addEventListener('click', () => {
  if (recordingHotkey) return;
  
  recordingHotkey = true;
  btnRecordHotkey.textContent = 'Press Keys...';
  hotkeyInput.value = 'Listening...';
  hotkeyInput.style.borderColor = '#8b5cf6';
});

window.addEventListener('keydown', (e) => {
  if (!recordingHotkey) return;
  e.preventDefault();
  
  const key = e.key.toLowerCase();
  
  // Filter modifier keys
  if (['control', 'shift', 'alt', 'meta'].includes(key)) {
    return;
  }
  
  const parts = [];
  if (e.ctrlKey) parts.push('ctrl');
  if (e.shiftKey) parts.push('shift');
  if (e.altKey) parts.push('alt');
  
  let keyName = key;
  if (key === ' ') keyName = 'space';
  parts.push(keyName);
  
  const hotkeyStr = parts.join('+');
  hotkeyInput.value = hotkeyStr;
  config.hotkey = hotkeyStr;
  
  recordingHotkey = false;
  btnRecordHotkey.textContent = 'Record';
  hotkeyInput.style.borderColor = 'rgba(255, 255, 255, 0.12)';
});

// ----------------------------------------------------
// 5. Reminders & Focus Timers Engine UI
// ----------------------------------------------------
async function renderReminders() {
  config = await ipcRenderer.invoke('get-config');
  const reminders = config.reminders || [];
  
  activeRemindersList.innerHTML = '';
  pastRemindersList.innerHTML = '';
  
  const activeItems = reminders.filter(r => r.status === 'active');
  const pastItems = reminders.filter(r => r.status !== 'active');
  
  // Render Active Timers/Reminders
  if (activeItems.length === 0) {
    activeRemindersList.innerHTML = `
      <div class="settings-card card-info" style="opacity: 0.9;">
        <div class="card-details">
          <span class="card-title">No active countdowns</span>
          <span class="card-desc">Set one from the quick schedule box, or use <code>/timer</code> / <code>/reminder</code> in the Command Bar.</span>
        </div>
      </div>
    `;
  } else {
    activeItems.forEach(item => {
      const card = document.createElement('div');
      card.classList.add('settings-card');
      
      const typeLabel = item.type === 'timer' ? 'Timer' : 'Reminder';
      const formattedTime = new Date(item.expiresAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      
      card.innerHTML = `
        <div class="reminder-card-status active"></div>
        <div class="card-details">
          <span class="card-title"><strong style="font-weight: 600; color: var(--accent-primary-hover); font-size: 10px; text-transform: uppercase; margin-right: 6px;">[${typeLabel}]</strong>${item.text}</span>
          <span class="card-desc">Duration: ${item.duration}m | Target: ${formattedTime}</span>
        </div>
        <button class="icon-action-btn btn-cancel-reminder" data-id="${item.id}" title="Cancel Countdown">
          ${trashSvg}
        </button>
      `;
      activeRemindersList.appendChild(card);
    });
    
    // Bind Cancel Click Events
    document.querySelectorAll('.btn-cancel-reminder').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = btn.getAttribute('data-id');
        await ipcRenderer.invoke('cancel-reminder', id);
        renderReminders();
      });
    });
  }
  
  // Render History
  if (pastItems.length === 0) {
    pastRemindersList.innerHTML = `
      <div style="color: var(--text-muted); text-align: center; padding: 24px; font-size: 12px;">
        History is currently empty
      </div>
    `;
  } else {
    // Show newest first
    pastItems.slice().reverse().forEach(item => {
      const card = document.createElement('div');
      card.classList.add('settings-card');
      card.style.opacity = '0.7';
      
      const typeLabel = item.type === 'timer' ? 'Timer' : 'Reminder';
      const statusClass = item.status === 'completed' ? 'completed' : 'cancelled';
      const statusLabel = item.status.charAt(0).toUpperCase() + item.status.slice(1);
      
      card.innerHTML = `
        <div class="reminder-card-status ${statusClass}"></div>
        <div class="card-details">
          <span class="card-title"><strong style="font-weight: 600; color: var(--text-muted); font-size: 10px; text-transform: uppercase; margin-right: 6px;">[${typeLabel}]</strong>${item.text}</span>
          <span class="card-desc-sub">${statusLabel} (${item.duration}m)</span>
        </div>
      `;
      pastRemindersList.appendChild(card);
    });
  }
}

btnSaveReminder.addEventListener('click', async () => {
  const type = reminderTypeSelect.value;
  const text = reminderTextInput.value.trim() || (type === 'timer' ? 'Focus Session' : 'Quick Reminder');
  const mins = parseInt(reminderMinsInput.value);
  
  if (isNaN(mins) || mins <= 0) {
    alert('Please enter a valid duration in minutes.');
    return;
  }
  
  await ipcRenderer.invoke('add-reminder', type, text, mins);
  reminderTextInput.value = '';
  renderReminders();
});

btnClearHistory.addEventListener('click', async () => {
  if (confirm('Are you sure you want to clear completed/cancelled history logs?')) {
    await ipcRenderer.invoke('clear-reminder-history');
    renderReminders();
  }
});

// Update reminders UI in real-time when timers finish in background
ipcRenderer.on('reminders-updated', () => {
  if (document.getElementById('view-reminders').classList.contains('active')) {
    renderReminders();
  }
});

// ----------------------------------------------------
// Save & Quit Actions
// ----------------------------------------------------
btnSaveAll.addEventListener('click', async () => {
  // Extract custom softwares paths from DOM elements to be extra safe
  document.querySelectorAll('.sw-path-input').forEach(input => {
    const swName = input.getAttribute('data-software');
    config.softwares[swName].exec_path = input.value.trim();
  });
  document.querySelectorAll('.sw-dir-input').forEach(input => {
    const swName = input.getAttribute('data-software');
    config.softwares[swName].default_dir = input.value.trim();
  });
  document.querySelectorAll('.sw-color-input').forEach(input => {
    const swName = input.getAttribute('data-software');
    config.softwares[swName].icon_color = input.value;
  });
  
  // Save default projects directory
  config.default_projects_dir = defaultDirInput.value.trim();

  const success = await ipcRenderer.invoke('save-config', config);
  if (success) {
    alert('All settings saved successfully and hotkeys updated!');
  } else {
    alert('Failed to save settings.');
  }
});

btnQuitApp.addEventListener('click', () => {
  if (confirm('Are you sure you want to fully close the cockpit engine? The global hotkey will stop working.')) {
    ipcRenderer.send('exit-app');
  }
});

// ----------------------------------------------------
// Software Modal Interactions
// ----------------------------------------------------
btnAddSoftware.addEventListener('click', () => {
  modalSoftName.value = '';
  modalSoftPath.value = '';
  modalSoftColor.value = '#478cbf';
  modalSoftColorHex.value = '#478cbf';
  modalSoftDir.value = '';
  softwareModal.classList.remove('hidden');
});

modalSoftColor.addEventListener('input', () => {
  modalSoftColorHex.value = modalSoftColor.value;
});

modalSoftColorHex.addEventListener('input', () => {
  if (/^#[0-9a-fA-F]{6}$/.test(modalSoftColorHex.value)) {
    modalSoftColor.value = modalSoftColorHex.value;
  }
});

modalSoftCancel.addEventListener('click', () => {
  softwareModal.classList.add('hidden');
});

modalSoftSave.addEventListener('click', async () => {
  const name = modalSoftName.value.trim();
  const execPath = modalSoftPath.value.trim();
  const iconColor = modalSoftColor.value;
  const defaultDir = modalSoftDir.value.trim();

  if (!name) {
    alert('Software Name is required.');
    return;
  }
  if (!execPath) {
    alert('Executable Path is required.');
    return;
  }

  config.softwares = config.softwares || {};
  config.softwares[name] = {
    exec_path: execPath,
    icon_color: iconColor,
    default_dir: defaultDir
  };

  // Save changes to disk immediately
  await ipcRenderer.invoke('save-config', config);

  softwareModal.classList.add('hidden');
  renderSoftwares();
  populateSoftwareDropdown();
});

// ----------------------------------------------------
// Project Deletion Warning Modal Interactions
// ----------------------------------------------------
btnDeleteCockpitOnly.addEventListener('click', async () => {
  if (projectToDeleteIndex >= 0) {
    config.projects.splice(projectToDeleteIndex, 1);
    await ipcRenderer.invoke('save-config', config);
    closeDeleteConfirmation();
    renderProjects();
  }
});

btnDeleteFull.addEventListener('click', async () => {
  if (projectToDeleteIndex >= 0) {
    const proj = config.projects[projectToDeleteIndex];
    
    // Safety check: confirm physical deletion one more time since it's recursive rmSync
    if (!confirm(`Warning: This will physically delete ALL files in "${proj.path}". This cannot be undone. Are you absolutely sure?`)) {
      return;
    }
    
    const res = await ipcRenderer.invoke('delete-project-folder', proj.path);
    if (res.success) {
      config.projects.splice(projectToDeleteIndex, 1);
      await ipcRenderer.invoke('save-config', config);
      closeDeleteConfirmation();
      renderProjects();
    } else {
      alert(`Failed to delete files on disk:\n${res.error}\n\nProject has NOT been removed.`);
    }
  }
});

btnDeleteCancel.addEventListener('click', () => {
  closeDeleteConfirmation();
});

// ----------------------------------------------------
// Project Explorer Action Buttons
// ----------------------------------------------------
btnExplorerBack.addEventListener('click', () => {
  switchView('projects');
  currentExplorerProject = null;
});

btnExplorerOpen.addEventListener('click', async () => {
  if (currentExplorerProject && currentExplorerProject.path) {
    const res = await ipcRenderer.invoke('open-project-folder', currentExplorerProject.path);
    if (!res.success) {
      alert(`Failed to open folder:\n${res.error}`);
    }
  }
});

btnExplorerZip.addEventListener('click', async () => {
  if (currentExplorerProject && currentExplorerProject.path) {
    btnExplorerZip.disabled = true;
    const originalText = btnExplorerZip.innerHTML;
    btnExplorerZip.innerHTML = '<span style="font-size:11px;">Compressing...</span>';
    const res = await ipcRenderer.invoke('zip-project-folder', currentExplorerProject.path);
    btnExplorerZip.disabled = false;
    btnExplorerZip.innerHTML = originalText;
    
    if (res.success) {
      alert(`Project zipped successfully! Saved archive:\n${res.zipPath}`);
    } else {
      alert(`Failed to zip project:\n${res.error}`);
    }
  }
});

// Status Bar updates
function updateFocusStatusBar(active) {
  const statusFocusText = document.getElementById('status-focus-text');
  if (statusFocusText) {
    if (active) {
      statusFocusText.textContent = 'Active';
      statusFocusText.className = 'status-badge-active';
    } else {
      statusFocusText.textContent = 'Inactive';
      statusFocusText.className = 'status-badge-inactive';
    }
  }
}

// Sync focus status in real time
ipcRenderer.on('focus-status', (event, active) => {
  updateFocusStatusBar(active);
});

// System project modal handler
btnSystemProjectOk.addEventListener('click', () => {
  systemProjectModal.classList.add('hidden');
});

// Start app
init();
